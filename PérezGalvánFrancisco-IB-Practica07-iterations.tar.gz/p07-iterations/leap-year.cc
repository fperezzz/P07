#include <iostream>

bool leap_year(int year){
  if (year % 100 == 0){
    if (year % 400 == 0){
      return true;
    }
    return false;
  }
  else if (year % 4 == 0){
    return true;
  }
  else {
    return false;
  }
}

int main() {
  int year;
  std::cin >> year;
  if (leap_year(year) == 0) {
    std::cout << "NO" << std::endl;
  }
  else {
    std::cout << "YES" << std::endl;
  }
  return 0;
}

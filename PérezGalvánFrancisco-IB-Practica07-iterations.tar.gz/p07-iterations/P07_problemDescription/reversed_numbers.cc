/** 
     * Universidad de La Laguna
     * Escuela Superior de Ingeniería y Tecnología
     * Grado en Ingeniería Informática
     * Informática Básica 2023-2024
     * 
     * reversed_numbers.cc
     * Francisco Pérez Galván alu0101673837@ull.edu.es
     * Nov 2 2023
     * El programa lee un numero y lo invierte
*/

#include <iostream>

int InvertirNumero(int numero) {
  int invertido = 0;
  while (numero > 0){
    if (numero % 10 == 0) {
    }
    invertido = invertido * 10 + (numero % 10);
    numero = numero / 10;
  }
  return invertido;
}

int main () {
  int numero;
  std::cin >> numero;
  std::cout << InvertirNumero(numero) << std::endl;
  return 0;
}

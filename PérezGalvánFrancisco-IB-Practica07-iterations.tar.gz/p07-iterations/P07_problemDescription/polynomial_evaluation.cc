/** 
    * Universidad de La Laguna
    * Escuela Superior de Ingeniería y Tecnología
    * Grado en Ingeniería Informática
    * Informática Básica 2023-2024
    * 
    * polynomial_evaluation.cc
    * Francisco Pérez Galván alu0101673837@ull.edu.es
    * Nov 03 2023
    * El programa lee un valor de x y un polinomio, para luego dar el valor de p(x).
*/

#include <iostream>
#include <cmath>

int ValorPolinomio (int valor_x, int numeros) {
  int exponente = 0, polinomio, suma = 0;
  while (numeros != 0) {
    polinomio = numeros * std::pow(valor_x,exponente);
    exponente ++;
    suma += polinomio;
  }
  return suma;
}

int main() {
  int valor_x, numeros;
  std::cin >> valor_x;
  std::cin >> numeros;
  std::cout << ValorPolinomio (valor_x, numeros) << ".0000";
return 0;
}


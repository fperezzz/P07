#include <iostream>

int main() {
  int terminos_fibonacci;
  std::cout << "Introduzca cuantos términos desea imprimir: ";
  std::cin >> terminos_fibonacci;

  int first = 0, second = 1, next;

  std::cout << "Serie de Fibonacci: ";
  for (int i = 0; i < terminos_fibonacci; i++) {
    // Caso base
    if (terminos_fibonacci <= 1) { next = first; }
    // Caso general
    else {
      next = first + second;
      first = second;
      second = next;
    }
    std::cout << next << " ";
  }
  std::cout << std::endl;
  
  return 0;
}

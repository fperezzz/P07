#include <iostream>

int convert(int decimal) {
  int binario = 0, i = 1, resto = 0;
  while (decimal != 0) {
    resto = decimal % 2;
    decimal /= 2;
    binario += resto*i;
    i *= 10;
  }
  return binario;
}

int main() {
  int decimal;
  std::cin >> decimal;
  std::cout << convert(decimal) << std::endl;
  return 0;
}

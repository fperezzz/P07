#include <iostream>
#include <string>

int main() {
  std::string numero;
  int contador = 0;
  std::cin >> numero;
  for (char digito : numero) {
    if (std::isdigit(digito)) {
      contador += (digito - 48);
    }
  }
  std::cout << contador << std::endl;

  return 0;
}

#include <iostream>
#include <cmath>

int convert(int binario) {
  int decimal = 0, i = 0, resto = 0;
  
  while (binario != 0) {
    resto = binario % 10;
    if (resto > 1) {
      std::cout << "Wrong input" << std::endl;
      return 0;
    }
    binario /= 10;
    decimal += resto*std::pow(2,i);
    i++;
  }
  
  return decimal;
}

int main() {
  int binario;
  std::cin >> binario;
  if (convert(binario) != 0) {
    std::cout << convert(binario) << std::endl;
  }
  return 0; 
}
